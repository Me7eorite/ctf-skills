#!/usr/bin/env python3
"""Base64+LSB双重编码解码脚本"""

from PIL import Image
import struct
import base64

def extract_base64_lsb(image_path):
    """提取LSB数据并Base64解码"""
    img = Image.open(image_path)
    pixels = img.load()
    width, height = img.size

    bits = []
    for y in range(height):
        for x in range(width):
            r, g, b = pixels[x, y]
            bits.extend([r & 1, g & 1, b & 1])

    bytes_data = []
    for i in range(0, len(bits), 8):
        byte_str = ''.join(str(b) for b in bits[i:i+8])
        if len(byte_str) == 8:
            bytes_data.append(int(byte_str, 2))

    # 提取base64数据
    if len(bytes_data) >= 4:
        length = struct.unpack('>I', bytes(bytes_data[:4]))[0]
        b64_data = bytes(bytes_data[4:4+length]).decode()

        print(f"提取的Base64数据: {b64_data}")

        # Base64解码
        decoded = base64.b64decode(b64_data).decode()
        return decoded

    return bytes(bytes_data).decode(errors='ignore')

hidden = extract_base64_lsb('challenge.png')
print(f"最终Flag: {hidden}")