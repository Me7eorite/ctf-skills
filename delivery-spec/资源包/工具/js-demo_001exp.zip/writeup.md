# Base64+LSB双重编码 - 解题报告

## 一、题目分析

- **题目名称**: Base64+LSB双重编码
- **难度**: Medium
- **考察点**: LSB提取 + Base64解码

## 二、题目描述

LSB数据不是直接可读的，需要额外解码。

## 三、解题过程

### 3.1 LSB提取

```bash
$ zsteg challenge.png
(无明显flag)
```

### 3.2 手动提取+解码

```python
from PIL import Image
import struct
import base64

img = Image.open('challenge.png')
bits = []
for y in range(img.height):
    for x in range(img.width):
        for val in img.getpixel((x, y)):
            bits.append(val & 1)

bytes_data = []
for i in range(0, len(bits), 8):
    byte_str = ''.join(str(b) for b in bits[i:i+8])
    if len(byte_str) == 8:
        bytes_data.append(int(byte_str, 2))

length = struct.unpack('>I', bytes(bytes_data[:4]))[0]
b64_data = bytes(bytes_data[4:4+length]).decode()

print(f"Base64数据: {b64_data}")
print(f"解码: {base64.b64decode(b64_data).decode()}")
```

```bash
$ python3 exp.py
Base64数据: ZmxhZ3tiNjRsc2JfcDdwNng3N24yZ281fQ==
最终Flag: flag{b64lsb_p7p6x77n2go5}
```

## 四、技术原理

双重编码：
- 第一层: Base64编码flag
- 第二层: LSB嵌入到图片
- 需要先LSB提取，再Base64解码

## 五、Flag

```
flag{b64lsb_p7p6x77n2go5}
```